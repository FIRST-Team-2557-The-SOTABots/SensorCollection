# bear-essentials

[![Maven Central](https://maven-badges.herokuapp.com/maven-central/org.tahomarobotics/bear-essentials/badge.svg)](https://maven-badges.herokuapp.com/maven-central/org.tahomarobotics/bear-essentials)